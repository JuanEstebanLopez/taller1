<?php

$servidor="localhost";
$usuario="root";
$contrasena="";
$conexion=mysqli_connect($servidor,$usuario,$contrasena) or die("Error con la conexión a la base de datos.");
//echo "Base de datos conectada.";
?>